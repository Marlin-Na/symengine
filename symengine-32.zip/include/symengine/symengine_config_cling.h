#ifndef SYMENGINE_CONFIG_CLING_HPP
#define SYMENGINE_CONFIG_CLING_HPP

#pragma cling add_library_path("C:/symengine/lib")
#pragma cling load("libsymengine")

#endif
